pyqt-omniviewer archive sample
